﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("********Program to calculate electricity and water bills******** ");
// Declare the function to handle the program
void Calculateelectricityandwaterbills()
{
    Console.WriteLine("Enter the customer's full name:");
    string customer = Convert.ToString(Console.ReadLine());
    Console.WriteLine("Please select customer type");
    Console.WriteLine("Enter number 1 if you are a household customer, then press enter");
    Console.WriteLine("Enter number 2 if you are a customer of an administrative agency or public service, then press enter");
    Console.WriteLine("Enter number 3 if you are a production units customer, then press enter");
    Console.WriteLine("Enter number 4 if you are a business services customer, then press enter");
    int typeCustomer = Convert.ToInt32(Console.ReadLine());
    if (typeCustomer == 1)
    {
        // Household customer
        // Required to enter the number of family members
        Console.WriteLine("Enter the number of family members");
        int numberMember = Convert.ToInt32(Console.ReadLine());
        if (numberMember >= 1)
        {
            Console.WriteLine("Please enter last month's water meter reading");
            int waterNumberLastMonth = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Please enter the current month's water meter reading");
            int waterNumberCurrentMonth = Convert.ToInt32(Console.ReadLine());
            if (waterNumberCurrentMonth >= waterNumberLastMonth)
            {
                int waterNumber = waterNumberCurrentMonth - waterNumberLastMonth;
                double waterNumberPeople = waterNumber / numberMember;
                double money = 0;
                if (waterNumberPeople > 0 && waterNumber <= 10)
                {
                    money = waterNumberPeople * 5973 * 1.1;
                }
                else if (waterNumberPeople > 10 && waterNumberPeople < 20)
                {
                    money = waterNumber * 7051 * 1.1;
                }
                else if (waterNumberPeople > 20 && waterNumberPeople <= 30)
                {
                    money = waterNumber * 8699 * 1.1;
                }
                else
                {
                    money = waterNumber * 15929 * 1.1;
                }
                Console.WriteLine("Your family's water bill is: {0} ", money);
            }
            else
            {
                Console.WriteLine("The previous month's water meter reading is not greater than the current month's");
            }
        }
        else
        {
            Console.WriteLine("You are not a household customer");
        }
    }
    else if (typeCustomer == 2)
    {
        // Administrative agency, public services
        Console.WriteLine("Please enter last month's water meter reading");
        int waterLastMonth = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Please enter the current month's water meter reading");
        int waterCurentMonth = Convert.ToInt32(Console.ReadLine());
        if (waterCurentMonth >= waterLastMonth)
        {
            double m = (waterCurentMonth - waterLastMonth) * 9955 * 1.1;
            Console.WriteLine("Water fees of public administrative agencies or public service are: {0}", m);
        }
        else
        {
            Console.WriteLine("The previous month's water meter reading is not greater than the current month's");
        }
    }
    else if (typeCustomer == 3)
    {
        // Production units customer
        Console.WriteLine("Please enter last month's water meter reading");
        int waterLastMonth3 = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Please enter the current month's water meter reading");
        int waterCurrentMonth3 = Convert.ToInt32(Console.ReadLine());
        if (waterCurrentMonth3 >= waterLastMonth3)
        {
            double m3 = (waterCurrentMonth3 - waterLastMonth3) * 11615 * 1.1;
            Console.WriteLine("Water cost of production unit is: {0}", m3);
        }
        else
        {
            Console.WriteLine("The previous month's water meter reading is not greater than the current month's");
        }
    }
    else if (typeCustomer == 4)
    {
        // Business services customer
        Console.WriteLine("Please enter last month's water meter reading");
        int waterLastMonth4 = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Please enter the current month's water meter reading");
        int waterCurrentMonth4 = Convert.ToInt32(Console.ReadLine());
        if(waterCurrentMonth4 >= waterLastMonth4)
        {
            double m4 = (waterCurrentMonth4 - waterLastMonth4) * 22068 * 1.1;
            Console.WriteLine("Business service water charges are: {0}", m4);
        }
        else
        {
            Console.WriteLine("The previous month's water meter reading is not greater than the current month's");
        }
    }
    else
    {
        Console.WriteLine("Please enter the correct customer type");
    }

}
// run program
Calculateelectricityandwaterbills();